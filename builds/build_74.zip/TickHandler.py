import time
import pyglet
import globals as G


class TickHandler:
    def __init__(self):
        pyglet.clock.schedule_interval(self.game_tick, 1/20)
        self.active_tick = 0
        self.game_tick_shedule = {}

    def game_tick(self, dt):
        if self.active_tick in self.game_tick_shedule:
            functions = self.game_tick_shedule[self.active_tick]
            for function in functions:
                function[0](*function[1], **function[2])
        self.active_tick += 1

    def tick_function(self, function, ticks, *args, **kwargs):
        if ticks <= 0: return
        tick_todo = self.active_tick + ticks
        if tick_todo not in self.game_tick_shedule: self.game_tick_shedule[tick_todo] = []
        self.game_tick_shedule[tick_todo].append(function)


handler = TickHandler()

