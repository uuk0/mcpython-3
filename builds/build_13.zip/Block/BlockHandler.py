import globals as G


class BlockHandler:
    def __init__(self):
        self.blocks = {}

    def __call__(self, *args, **kwargs):
        iblock = args[0]
        name = iblock.getName().split(":")
        for i in range(len(name)):
            self.blocks[":".join(name[i:])] = iblock

    def register(self, klass):
        self(klass)


G.blockhandler = BlockHandler()

