import util.vertices
import globals as G


class IBlock:
    """
    basic class for all blocks
    """

    @staticmethod
    def getName():
        """
        :return: the name as the block should be accessable
        """
        return "minecraft:NONE"

    @staticmethod
    def getTextureData():
        """
        :return: a list of all texture sides as indexes
        """
        return [(0, 0)] * 6

