import util.vertices


GRASS = util.vertices.tex_coords((1, 0), (0, 1), (0, 0))
SAND = util.vertices.tex_coords((1, 1), (1, 1), (1, 1))
BRICK = util.vertices.tex_coords((2, 0), (2, 0), (2, 0))
STONE = util.vertices.tex_coords((2, 1), (2, 1), (2, 1))

