"""
mcpython is an minecraft clone written in python using pyglet
it is based on code of fogleman
"""

import config
import globals as G
import rendering.window
import setup
import pyglet
import sys
import shutil
import os

if "--debug" in sys.argv:
    G.CONFIG["BUILD"] += 1
    config.store()
    import builder
    builder.build()

# Startup header

print("-------------------"+"-"*len(str(G.CONFIG["BUILD"])))
print("- mcpython build "+str(G.CONFIG["BUILD"])+" -")
print("-------------------"+"-"*len(str(G.CONFIG["BUILD"])))
print("\n"*3)


print("cleaning up tmp-dir")

if not os.path.exists(G.local+"/tmp"): os.makedirs(G.local+"/tmp")
for path in os.listdir(G.local+"/tmp"):
    shutil.rmtree(G.local+"/tmp/"+path)


# loading own moduls

import texture.TextureAtlas
import Block.BlockHandler



# Starting game

def main():
    window = rendering.window.Window(width=800, height=600, caption='Mcpython build '+str(G.CONFIG["BUILD"]),
                                     resizable=True)
    # Hide the mouse cursor and prevent the mouse from leaving the window.
    window.set_exclusive_mouse(True)
    setup.setup()
    pyglet.app.run()


if __name__ == '__main__':
    main()
