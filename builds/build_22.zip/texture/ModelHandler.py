import globals as G
import texture.TextureAtlas
import json
import util.vertices, util.vector
import pyglet
import os


class ModelHandler:
    def __init__(self):
        self.models = {}
        self.modelindex = {}

    def add_model(self, file):
        if file in self.models: return self.models[file]
        with open(file) as f:
            model = Model(json.load(f))
            self.models[file] = model
            self.modelindex[model.name] = model
        return self.models[file]

    def generate(self):
        for model in self.models.values():
            model.generate()

    def show(self, position):
        block = G.model.world[position]
        self.modelindex[block.getName()].entrys[block.get_active_model_index()].show(position)

    def hide(self, position):
        block = G.model.world[position]
        self.modelindex[block.getName()].entrys[block.get_active_model_index()].hide(position)


G.modelhandler = ModelHandler()


class IModelEntry:
    ENTRYS = {}

    def __init__(self, entrydata, model):
        self.data = entrydata
        self.model = model

    @staticmethod
    def getName():
        return ""

    def show(self, position):
        pass

    def hide(self, position):
        pass


class BoxModelEntry(IModelEntry):
    @staticmethod
    def getName():
        return "cube"

    def show(self, position):
        if position in G.model._shown: self.hide(position)
        block = G.model.world[position]
        textureatlas = G.textureatlashandler.atlases[self.model.indexes[0][0]]
        x, y, z = position
        vertex_data = util.vertices.cube_vertices(x, y, z, 0.5)
        data = []
        for element in self.data["indexes"]:
            data.append(textureatlas.filearray[self.model.indexes[element][1]])
        texture_data = list(util.vertices.tex_coords(*data))
        # create vertex list
        # FIXME Maybe `add_indexed()` should be used instead
        G.model._shown[position] = G.model.batch.add(24, pyglet.gl.GL_QUADS, textureatlas.pygletatlas,
                                               ('v3f/static', vertex_data),
                                               ('t2f/static', texture_data))

    def hide(self, position):
        if position not in G.model._shown: return
        G.model._shown.pop(position).delete()


IModelEntry.ENTRYS[BoxModelEntry.getName()] = BoxModelEntry


class Model:
    def __init__(self, data):
        self.data = data
        self.files = data["files"]
        self.indexes = []
        self.entrys = []
        self.name = data["name"]

    def generate(self):
        self.indexes = G.textureatlashandler.add_images(self.files)
        for entry in self.data["entrys"]:
            if entry["name"] in IModelEntry.ENTRYS:
                self.entrys.append(IModelEntry.ENTRYS[entry["name"]](entry, self))
            else:
                raise ValueError("can't cast model entry data " + str(entry) + " to an model entry")


for e in os.listdir(G.local+"/assets/models/block"):
    G.modelhandler.add_model(G.local+"/assets/models/block/"+e)

