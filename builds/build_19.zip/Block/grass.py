import Block.IBlock
import globals as G


@G.blockhandler
class Grass(Block.IBlock.IBlock):
    @staticmethod
    def getName():
        return "minecraft:grass"

    def getTextureData(self):
        return [(1, 0), (0, 1), (0, 0), (0, 0), (0, 0), (0, 0)]

