import Block.IBlock
import globals as G


@G.blockhandler
class Sand(Block.IBlock.IBlock):
    @staticmethod
    def getName():
        return "minecraft:sand"

    def getTextureData(self):
        return [(1, 1)] * 6

