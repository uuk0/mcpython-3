import Block.IBlock
import globals as G


@G.blockhandler
class Stone(Block.IBlock.IBlock):
    @staticmethod
    def getName():
        return "minecraft:stone"

    def getTextureData(self):
        return [(2, 1)] * 6

    def isBrakeAble(self):
        return False

